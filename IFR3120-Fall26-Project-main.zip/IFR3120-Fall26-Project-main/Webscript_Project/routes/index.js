let express = require('express');
let router = express.Router();

/* GET login page. */
router.get('/login', function(req, res, next) {
  res.render('login', { title: 'Login Page' });
});

/* GET home page 2*/
router.get('/home', function(req, res, next) {
  res.render('Home_Page', { title: 'Home Page' });
});

/* GET checkout page*/
router.get('/checkout', function(req, res, next) {
  res.render('checkout', { title: 'Check Out' });
});

/* GET login page*/
router.get('/login', function(req, res, next) {
  res.render('login', { title: 'Login Page' });
});


module.exports = router;
