# INFR3120_Fall2026_Project Log
## v0.0.1 by Marcus Pasco
### Added
- Ejs files: unified header & footer and home page format

### Improvements

## v0.0.0 by Marcus Pasco
### Added
- Generated the expreess-generator skeleton format

### Improvements

## v0.0.0 by Aksayan Nirmalan
### Added
- created view ejs for login, checkout and partial view for navbar
Mark Otto, J. T. (n.d.). Navbar. · Bootstrap v5.0. https://getbootstrap.com/docs/5.0/components/navbar/ 

### Improvements

